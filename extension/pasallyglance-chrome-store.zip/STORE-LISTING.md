# PasallyGlance — Chrome Web Store Listing

Everything below is ready to paste into the Web Store developer dashboard.

---

## Item name
PasallyGlance

## Category
Productivity

## Short description (≤132 characters)
Select or right-click anything on a page for an instant, context-aware AI answer. Privacy-first, bring your own key.

## Detailed description
PasallyGlance turns any web page into something you can ask about.

Select a sentence and a small chip appears — tap it to explain, summarize, translate, or ask your own question. Or right-click anything at all (text, an image, a link, or the whole page) and choose "Ask AI about this." The answer streams into a tidy panel right where you're working, and you can ask follow-ups, go deeper with a stronger model, copy the result, or drop a drafted reply straight into Gmail.

It adapts to what you point at:
• Text — explain, summarize, define, translate, or ask anything
• Images — "What is this?" for objects, landmarks, and products
• Email (Gmail) — draft a reply, summarize a thread, pull out action items
• Code — explain what a snippet does
• Tables — read and answer questions about the data
• Links — get a quick preview of where they go

Privacy is the whole point. PasallyGlance has no servers of its own. You bring your own Anthropic API key, it's stored only in your browser, and the only thing that ever leaves your machine is the specific content you choose to ask about — sent straight to Anthropic, with nothing in between. No accounts, no analytics, no tracking.

Nothing ever fires a network request on its own. The chip is local until you tap an action, so you're always the one who decides when a question is asked.

Bring-your-own-key means you choose the model and pay Anthropic directly at cost. Fast model (Haiku) by default for quick answers, with a one-tap "Go deeper" to a stronger model (Sonnet) when you want it.

## Single-purpose description
PasallyGlance has one purpose: to let the user get an AI-generated answer, explanation, or summary about content they select or right-click on a web page, using their own Anthropic API key.

---

## Permission justifications
(Paste each into the matching field during review.)

**storage**
Saves the user's settings and their own Anthropic API key locally in the browser. Nothing is stored remotely.

**contextMenus**
Adds the right-click "Ask AI about this" menu item so the user can invoke the assistant on text, images, links, or the page.

**Host permission — https://api.anthropic.com/**
The extension sends the content the user selected to Anthropic's API, using the user's own key, to generate the answer. This is the only host the extension contacts.

**Content scripts on <all_urls>**
The selection chip and answer panel need to be able to appear on whatever page the user decides to use the tool on, so the content script must be allowed to run broadly. It reads no page content and sends nothing anywhere unless the user explicitly taps an action or chooses the right-click item.

---

## Privacy / data-handling disclosure
For the Web Store "Privacy practices" form:

- **What the extension handles:** the specific text or content the user selects or right-clicks, which is transmitted to Anthropic's API to generate a response. The user's API key and preferences.
- **Where it goes:** content goes only to https://api.anthropic.com using the user's own key. The API key and settings are stored only in the browser's local extension storage.
- **Collected by the developer:** none. The extension has no backend and does not collect, log, or transmit any data to the developer or any third party other than Anthropic.
- **Sold or shared:** no.
- **Used for:** solely to provide the answer the user requested. Not used for advertising, profiling, or any unrelated purpose.

Suggested data-safety checkboxes: "Personally identifiable information" is **not** collected by you; "Website content" is handled but **only** sent to the AI provider the user configured, and is **not** sold or used for purposes unrelated to the single purpose.

---

## Assets in this bundle
- `pasallyglance.zip` — the extension package; upload this as the item.
- `store-assets/store-icon-128.png` — 128×128 store icon (required).
- `store-assets/screenshot-1280x800.png` — 1280×800 screenshot (at least one required). Swap in real captures from the running extension when you can.
- `store-assets/promo-small-440x280.png` — small promo tile (recommended).
- `store-assets/promo-marquee-1400x560.png` — marquee promo tile (optional).

## Submission checklist
1. Create the item in the Chrome Web Store developer dashboard and upload `pasallyglance.zip`.
2. Fill in name, short + detailed description, and category (Productivity).
3. Upload the store icon and at least one screenshot; add promo tiles if you want them.
4. Complete the single-purpose field and the permission justifications above.
5. Complete the privacy practices form using the disclosure above and link a privacy policy (a short page stating the same "no data collected, BYO key, content goes only to Anthropic" is enough).
6. Submit for review.
